<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>end to end for setting up state on the portal</description>
   <name>Setup States</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>200cc804-56fe-4c4a-a500-69623197bfe9</testSuiteGuid>
   <testCaseLink>
      <guid>661d626d-9e71-4a3d-acb6-6a6174ed30f5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Launch Nimblex URL</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>86db2d91-42ee-478d-9fa1-a83fa0bb4b91</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>78909565-411a-44db-8009-8e45f5533f0d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Setup State</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
