<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>user launches the website, then inputs teh url.
once this is completed, user logs in with valid username and password</description>
   <name>Login</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f78ac74a-05a5-4b7e-b49e-3592786a62a6</testSuiteGuid>
   <testCaseLink>
      <guid>27610fa8-c15e-46dc-bf7a-00fa0a3dfc8c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Launch Nimblex URL</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9e2f5a10-9c09-4c2e-a84b-398b81c13fc4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User Login</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
